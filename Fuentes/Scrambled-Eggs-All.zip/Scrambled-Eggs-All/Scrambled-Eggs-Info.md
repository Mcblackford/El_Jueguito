# Scrambled Eggs
Scrambled Eggs is a 14pt pixel art font with a hand-drawn scribble style.

## Author
[VEXED](https://v3x3d.itch.io/)

## Basic Info
- Base Glyph Height: 14px
- Scales: 14, 28, 42, 56, etc
- Ascender Max: 5px
- Descender Max: 3px

## Kerning
None

## License
[Creative Commons Attribution v4.0 International](https://creativecommons.org/licenses/by/4.0/deed.en)

## Supported Glyphs (PNG Order)
``
ABCDEFGH
IJKLMNOP
QRSTUVWX
YZ
abcdefgh
ijklmnop
qrstuvwx
yz
01234567
89
 !"#$%&'
()*+,-./
:;<=>?[]
\^_`{}|~
@∎
ÄÁÀÂÅÃÇç
äáàâåãÑñ
ÏÍÌÎÜÚÙÛ
ïíìîüúùû
ÖÓÒÔÕŸÝỲ
öóòôõÿýỳ
ËÉÈÊëéèê
ÆæßðÐþÞ
¿¡Œœ
``

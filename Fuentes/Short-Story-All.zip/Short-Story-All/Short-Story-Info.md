# Short Story
Short Story is a 7pt pixel art font designed with compact yet stylish lettering. The lettering is also intended to pair with my font titled "Fabled Font".

## Author
[VEXED](https://v3x3d.itch.io/)

## Basic Info
- Base Glyph Height: 7px
- Scales: 7, 14, 21, 28, etc
- Ascender Max: 3px
- Descender Max: 3px

## Kerning
None

## License
[Creative Commons Attribution v4.0 International](https://creativecommons.org/licenses/by/4.0/deed.en)

## Supported Glyphs (PNG Order)
``
ABCDEFGH
IJKLMNOP
QRSTUVWX
YZ
abcdefgh
ijklmnop
qrstuvwx
yz
01234567
89
 !"#$%&'
()*+,-./
:;<=>?[]
\^_`{}|~
@∎
ÄÁÀÂÅÃÇç
äáàâåãÑñ
ÏÍÌÎÜÚÙÛ
ïíìîüúùû
ÖÓÒÔÕŸÝỲ
öóòôõÿýỳ
ËÉÈÊëéèê
ÆæßðÐþÞ
¿¡Œœ
``
